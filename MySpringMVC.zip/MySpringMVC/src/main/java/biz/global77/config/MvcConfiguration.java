package biz.global77.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.SingleConnectionDataSource;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import biz.global77.dao.JdbcLearnerDao;
import biz.global77.dao.JdbcLearnerDaoImpl;

@Configuration
@ComponentScan(basePackages="biz.global77")
@EnableWebMvc
public class MvcConfiguration implements WebMvcConfigurer {

	@Bean
	public JdbcLearnerDao getJdbcLearnerDao() {
		return new JdbcLearnerDaoImpl();
	}
	
	@Bean
	public DriverManagerDataSource getDataSource() {

		DriverManagerDataSource bds = new DriverManagerDataSource();
		bds.setDriverClassName("org.postgresql.Driver");
		bds.setUrl("jdbc:postgresql://localhost:5432/lms");
		bds.setUsername("postgres");
		bds.setPassword("root");

		return bds;
	}
	
	@Bean
	@Autowired
    public JdbcTemplate getJdbcTemplate(DataSource dataSource) {
        JdbcTemplate jdbcTemplate = new JdbcTemplate();
        jdbcTemplate.setDataSource(dataSource);
        jdbcTemplate.setQueryTimeout(20); //20 seconds
        jdbcTemplate.setFetchSize(10);  //fetch 10 rows at a time
        return jdbcTemplate;
    }
	
	@Bean
	public ViewResolver getViewResolver(){
		InternalResourceViewResolver resolver = new InternalResourceViewResolver();
		resolver.setPrefix("/WEB-INF/views/");
		resolver.setSuffix(".jsp");
		return resolver;
	}
	
	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
	}

	
}
