package biz.global77.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import biz.global77.dao.JdbcLearnerDao;
import biz.global77.form.Learner;

@Controller
public class LearnerController {

	@Autowired
	JdbcLearnerDao learnerDao;
	
	@RequestMapping(value = "/about_us", method = RequestMethod.GET)
	public ModelAndView showForm1() {
		return new ModelAndView("about_us");
	}
	
//	@RequestMapping(value = "/ListOfLearner", method = RequestMethod.GET)
//	public ModelAndView showForm2() {
//		return new ModelAndView("ListOfLearner");
//	}
	
	@RequestMapping(value = "/ListOfLearner")
	public ModelAndView showForm2(ModelAndView employee) {
		List<Learner> ListOfLearner = learnerDao.ListOfLearner();
		employee.addObject("ListOfLearner", ListOfLearner);
		return employee;
	}
	
	
	
	@RequestMapping(value = "/learner", method = RequestMethod.GET)
	public ModelAndView showForm() {
		return new ModelAndView("enrol", "learnerForm", new Learner());
		
	}
	
	
	@RequestMapping(value = "/learnerAction", method = RequestMethod.POST)
	public String submit(@Valid @ModelAttribute("learnerForm") Learner learner,
			BindingResult result, ModelMap model) {
		
		if(result.hasErrors()) {
			return "enrol";
		}
		
		learnerDao.insert(learner);
		
		String message = "We welcome you.. " + learner.getEmpName();
		// add message to model
		model.addAttribute("message", message);
		model.addAttribute("employeeName", learner.getEmpName());
		model.addAttribute("employeeID", learner.getEmpID());
		model.addAttribute("employeeAge", learner.getEmpAge());
		model.addAttribute("employeeEmail", learner.getEmpEmail());
		return "acknowledge";
		
	}
//		@RequestMapping(value= {"/","learner"}, method = RequestMethod.GET)
//		public String ListOfLearner(ModelMap model) {
//		model.addAttribute("ListOfLearner", learnerDao.findByAll());
//		return "learner";
//	}
//	
}
