package biz.global77.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import biz.global77.form.Learner;

public class JdbcLearnerDaoImpl implements JdbcLearnerDao {

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public void insert(Learner employee) {

		String sql = "INSERT INTO public.learner (\r\n" + 
		" \"empName\", \"empID\",\"empAge\",\"empEmail\")\r\n"
		+ " VALUES (?,?,?,?)";

		jdbcTemplate.update(sql, new Object[] {employee.getEmpName(),employee.getEmpID(),
				employee.getEmpAge(),employee.getEmpEmail(),});
	}
	
	@Override
	public List<Learner>ListOfLearner(){
		String sql = "SELECT * FROM	learner";
		List<Learner>learner = jdbcTemplate.query(sql, new RowMapper<Learner>(){
			@Override
			public Learner mapRow(ResultSet rs, int rowNum)throws SQLException{
				Learner learner = new Learner();
				learner.setEmpName(rs.getString("empName"));
				learner.setEmpID(rs.getString("empID"));
				learner.setEmpAge(rs.getString("empAge"));
				learner.setEmpEmail(rs.getString("empEmail"));
				return learner;
				}
			});
		return learner;
	
	}
	
//	public List<Learner> findByAll(){
//		String sql = "SELECT * FROM public.learner";
//		List<Learner> learner = (List<Learner>) jdbcTemplate.query(sql, new RowMapper<Learner>() {
//			@Override
//			public Learner mapRow(ResultSet rs, int rowNum) throws SQLException{
//				return new Learner(
//						rs.getString("empName"),
//						rs.getString("empID"),
//						rs.getString("empAge"),
//						rs.getString("empEmail"));
//			
//		}
//	});
//	return learner;
//	}
	

}
