package biz.global77.dao;

import java.util.List;

import biz.global77.form.Learner;

public interface JdbcLearnerDao {

	public void insert(Learner learner);
	
	List <Learner>ListOfLearner();
	
//	public List<Learner> findByAll();
}
